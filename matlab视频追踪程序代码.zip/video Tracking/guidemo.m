function varargout = guidemo(varargin)
% GUIDEMO M-file for guidemo.fig
%      GUIDEMO, by itself, creates a new GUIDEMO or raises the existing
%      singleton*.
%
%      H = GUIDEMO returns the handle to a new GUIDEMO or the handle to
%      the existing singleton*.
%
%      GUIDEMO('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUIDEMO.M with the given input arguments.
%
%      GUIDEMO('Property','Value',...) creates a new GUIDEMO or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before guidemo_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to guidemo_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help guidemo

% Last Modified by GUIDE v2.5 14-Sep-2014 10:00:52

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @guidemo_OpeningFcn, ...
                   'gui_OutputFcn',  @guidemo_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before guidemo is made visible.
function guidemo_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to guidemo (see VARARGIN)

% Choose default command line output for guidemo
handles.output = hObject;

a=ones(320,650);
imshow(a);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes guidemo wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = guidemo_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Browse.
function Browse_Callback(hObject, eventdata, handles)
% hObject    handle to Browse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

   [filename, pathname] = uigetfile('*.avi', 'Pick an VIDEO');
    if isequal(filename,0) || isequal(pathname,0)
       disp('User pressed cancel')
    else
      a=aviread(filename);

      handles.a=a;
      
    end
 
    % Update handles structure
guidata(hObject, handles);
    
% --- Executes on button press in PlayMovie.
function PlayMovie_Callback(hObject, eventdata, handles)
% hObject    handle to PlayMovie (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

B = '.png';
C = 'yjf-00_1-';
k=1;

for kk=1:50

        d=num2str(kk);
        e2=strcat(C,d);
        filename3 =strcat(e2,B);
        b=imread( filename3);
        imshow(b);
        pause(0.5);


end
% --- Executes on button press in framesepration.
function framesepration_Callback(hObject, eventdata, handles)
% hObject    handle to framesepration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

function BinaryPattern_Callback(hObject, eventdata, handles)
% hObject    handle to BinaryPattern (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes on button press in Tracking.
function Tracking_Callback(hObject, eventdata, handles)
% hObject    handle to Tracking (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

B = '.png';
C = 'yjf-00_1-';
k=1;

for kk=1:50

        d=num2str(kk);
        e2=strcat(C,d);
        filename3 =strcat(e2,B);
        a=imread('yjf-00_1-bk.png');
        b=imread( filename3);
        a1=a(:,:,1);
        a2=a(:,:,2);
        a3=a(:,:,3);
        [r c]=size(a1);
        b1=b(:,:,1);
        b2=b(:,:,2);
        b3=b(:,:,3);
        z1= imsubtract(a1,b1);
        z2= imsubtract(a2,b2);
        z3= imsubtract(a3,b3);

        fig(:,:,1)=z1;
        fig(:,:,2)=z2;
        fig(:,:,3)=z3;


        I2=rgb2gray(fig);
        I3 = imadjust(I2, stretchlim(I2), [0 1]);
        level = graythresh(I3);
        bw = im2bw(I3,level); 
        K = medfilt2(bw);
        K6 = medfilt2(K,[5,5]);
%         k6=double(K6);
%         K6=edge(K6,'canny');
%         imshow(K6,[])
   
        k=k+1;

        Image  = K6;
        % get size of image as H,W
        imshow(b);
        [H,W] = size(Image);
        [r,c] = find( bwperim(Image,4) == 1 );
        [tr,tc] = boundarytrack(r,c,H,W,0);
        X1=tr;
        Y1 =tc;
        XB=tr;
        YB =tc;
        Xmin = min(XB);
        Ymin = min(YB);
        Xmax = max(XB);
        Ymax = max(YB);
        X = [Xmin Xmax];
        Y = [Ymin Ymin];
        line(Y,X) ;
        X = [Xmin Xmin];
        Y = [Ymin Ymax];
        line(Y,X) ;
        X = [Xmax Xmax];
        Y = [Ymin Ymax];
        line(Y,X) ;
        X = [Xmin Xmax];
        Y = [Ymax Ymax];
        line(Y,X) ;
        Yg = Xmin+fix((Ymax-Ymin)/2);
        Xg = Ymin+fix((Xmax-Xmin)/2);
        line(Yg,Xg);
        pause(0.5);


end
