function [out]=findfeatures(img)
img           = double(img);
[dimx,dimy]   = size(img);
%[x,y]         = meshgrid(1:dimx,1:dimy);
%xc            = round(dimx/2);
%yc            = round(dimy/2);
%z0            = 1;
%gamma         = 0.0003;
%filtrogauss   = (z0*exp(-gamma*((x-xc).^2+(y-yc).^2)))';
%filtrogauss   = filtrogauss/sum(sum(filtrogauss));
%facegauss     = conv2fft(img,filtrogauss,'same');

mu0 = 0;
mu1 = 7;
ni0 = 0;
ni1 = 4;
L   = 100;
for mu=mu0:1:mu1
    for ni=ni0:1:ni1
        filtro = facegabor(L,mu,ni);
        %feature{mu+1,ni+1}=facegauss.*conv2fft(img,filtro,'same');
        feature{mu+1,ni+1} = conv2fft(img,filtro,'same');
        %feature{mu+1,ni+1} = filtrogauss.*conv2fft(img,filtro,'same');
    end
end

somma = zeros(dimx,dimy);
for ii=1:dimx
    for jj=1:dimy
        for mu=mu0:1:mu1
            for ni=ni0:1:ni1
                somma(ii,jj)=somma(ii,jj)+abs(feature{mu+1,ni+1}(ii,jj));
            end
        end
    end
end

media = sum(sum(somma))/prod(size(somma));

cont = 0;
for ii=1:dimx
    for jj=1:dimy
        x0 = max(1,ii-3);
        x1 = min(ii+3,dimx);
        y0 = max(1,jj-3);
        y1 = min(jj+3,dimy);
        if all(all(somma(ii,jj)>=somma(x0:x1,y0:y1))) && all(all(media<somma(x0:x1,y0:y1)))
            vettore = zeros(length(mu0:mu1)*length(ni0:ni1),1);
            pos     = 1;
            for mu=mu0:1:mu1
                for ni=ni0:1:ni1
                    vettore(pos) = feature{mu+1,ni+1}(ii,jj);
                    pos          = pos+1;
                end
            end
            cont = cont+1;
            out{cont} = vettore;
        end
    end
end

