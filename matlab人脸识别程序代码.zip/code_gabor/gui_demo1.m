function varargout = gui_demo1(varargin)
% GUI_DEMO1 M-file for gui_demo1.fig
%      GUI_DEMO1, by itself, creates a new GUI_DEMO1 or raises the existing
%      singleton*.
%
%      H = GUI_DEMO1 returns the handle to a new GUI_DEMO1 or the handle to
%      the existing singleton*.
%
%      GUI_DEMO1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI_DEMO1.M with the given input arguments.
%
%      GUI_DEMO1('Property','Value',...) creates a new GUI_DEMO1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_demo1_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_demo1_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui_demo1

% Last Modified by GUIDE v2.5 16-Apr-2007 10:29:59

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui_demo1_OpeningFcn, ...
                   'gui_OutputFcn',  @gui_demo1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui_demo1 is made visible.
function gui_demo1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui_demo1 (see VARARGIN)

% Choose default command line output for gui_demo1
handles.output = hObject;


A=ones(256,256);
axes(handles.axes2);

imshow(A);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes gui_demo1 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = gui_demo1_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Browse.
function Browse_Callback(hObject, eventdata, handles)
% hObject    handle to Browse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


         [namefile,pathname]=uigetfile('*.*','Select image');
        if namefile~=0
            [img,map]=imread(strcat(pathname,namefile));
            axes(handles.one);
            imshow(img);
            dimensioni = size(img);
            handles.img=img;
            % Update handles structure
            guidata(hObject, handles);
        else
            warndlg('Input image must be selected.',' Warning ')
        end


% --- Executes on button press in ADD_TO_DATABASE.
function ADD_TO_DATABASE_Callback(hObject, eventdata, handles)
% hObject    handle to ADD_TO_DATABASE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
messaggio='FACE RECOGNITION.';

img=handles.img;
if exist('img')
            if (exist('face_database.dat')==2)
                load('face_database.dat','-mat');
                face_number=face_number+1;
                data{face_number,1}=double(img);
                prompt={strcat(messaggio,'Class number must be a positive integer <= ',num2str(max_class))};
                title='Class number';
                lines=1;
                def={'1'};
                answer=inputdlg(prompt,title,lines,def);
                zparameter=double(str2num(char(answer)));
                if size(zparameter,1)~=0
                    class_number=zparameter(1);
                    if (class_number<=0)||(class_number>max_class)||(floor(class_number)~=class_number)||(~isa(class_number,'double'))||(any(any(imag(class_number))))
                        warndlg(strcat('Class number must be a positive integer <= ',num2str(max_class)),' Warning ')
                    else
                        disp('Features extraction...please wait');
                        if class_number==max_class;
                            % this person (class) has never been added to
                            % database before this moment
                            max_class = class_number+1;
                            features  = findfeatures(img);
                        else
                            % this person (class) has already been added to
                            % database
                            features  = findfeatures(img);
                        end


                        data{face_number,2} = class_number;
                        L = length(features);
                        for ii=1:L
                            features_data{features_size+ii,1} = features{ii};
                            features_data{features_size+ii,2} = class_number;
                        end
                        features_size = length(features_data);
                        clc;
                        save('face_database.dat','data','face_number','max_class','features_data','features_size','-append');
                        msgbox(strcat('Database already exists: image succesfully added to class number ',num2str(class_number)),'Database result','help');
                        close all;
                        clear('img')
                    end
                else
                    warndlg(strcat('Class number must be a positive integer <= ',num2str(max_class)),' Warning ')
                end
            else
                face_number=1;
                max_class=1;
                data{face_number,1}=double(img);
                prompt={strcat(messaggio,'Class number must be a positive integer <= ',num2str(max_class))};
                title='Class number';
                lines=1;
                def={'1'};
                answer=inputdlg(prompt,title,lines,def);
                zparameter=double(str2num(char(answer)));
                if size(zparameter,1)~=0
                    class_number=zparameter(1);
                    if (class_number<=0)||(class_number>max_class)||(floor(class_number)~=class_number)||(~isa(class_number,'double'))||(any(any(imag(class_number))))
                        warndlg(strcat('Class number must be a positive integer <= ',num2str(max_class)),' Warning ')
                    else
                        disp('Features extraction...please wait');
                        max_class=2;
                        data{face_number,2}=class_number;
                        features  = findfeatures(img);
                        L = length(features);
                        for ii=1:L
                            features_data{ii,1} = features{ii};
                            features_data{ii,2} = class_number;
                        end
                        features_size = length(features_data);
                        clc;
                        save('face_database.dat','data','face_number','max_class','features_data','features_size');
                        msgbox(strcat('Database was empty. Database has just been created. Image succesfully added to class number ',num2str(class_number)),'Database result','help');
                        close all;
                        clear('img')
                    end
                else
                    warndlg(strcat('Class number must be a positive integer <= ',num2str(max_class)),' Warning ')
                end

            end
        else
            errordlg('No image has been selected.','File Error');
        end
  
% --- Executes on button press in RECOGNITION.
function RECOGNITION_Callback(hObject, eventdata, handles)
% hObject    handle to RECOGNITION (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

img=handles.img;
        if exist('img')

            if (exist('face_database.dat')==2)
                load('face_database.dat','-mat');
                disp('Features extraction for face recognition...please wait');
                % code for face recognition
                features  = findfeatures(img);
                L = length(features);
                score = zeros(max_class-1,1);
                for ii=1:L
                    pesi = zeros(features_size,1);
                    for jj=1:features_size
                        pesi(jj)=norm(features{ii}-features_data{jj,1});
                    end
                    [val,pos]=min(pesi);
                    trovato = features_data{pos,2};
                    score(trovato)=score(trovato)+1;
                end
                [val,pos]=max(score);
                clc;
                pos1=pos;
                pos=num2str(pos);
                val=num2str(val);
                disp('Person recognized ID');
                set(handles.C,'String',pos);
                                set(handles.c2,'String',val);
                
            else
                warndlg('No image processing is possible. Database is empty.',' Warning ')
            end
        else
            warndlg('Input image must be selected.',' Warning ')
        end



        if pos1==1
            cd('a');
            a=imread('1.pgm');
            axes(handles.axes2);
            imshow(a);
            cd ..
        
            
        elseif pos1==2
            cd('b');
            a=imread('1.pgm');
            axes(handles.axes2);
            imshow(a);
            cd ..
            
        elseif pos1==3
            
            cd('c');
            a=imread('1.pgm');
            axes(handles.axes2);
            imshow(a);
            cd ..
            
        end







% --- Executes on button press in REMOVEDATABASE.
function REMOVEDATABASE_Callback(hObject, eventdata, handles)
% hObject    handle to REMOVEDATABASE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

        if (exist('face_database.dat')==2)
            button = questdlg('Do you really want to remove the Database?');
            if strcmp(button,'Yes')
                delete('face_database.dat');
                msgbox('Database was succesfully removed from the current directory.','Database removed','help');
            end
        else
            warndlg('Database is empty.',' Warning ')
        end
% --- Executes on button press in VIEWDATABASE.
function VIEWDATABASE_Callback(hObject, eventdata, handles)
% hObject    handle to VIEWDATABASE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

        if (exist('face_database.dat')==2)
            load('face_database.dat','-mat');
            AA=num2str(face_number);
            BB=num2str(max_class-1);
            set(handles.ti,'String',AA);
            set(handles.tc,'String',BB);
            msgbox(strcat('Database has ',num2str(face_number),' image(s). There are',num2str(max_class-1),' class(es). Input images must have the same size.'),'Database result','help');
        else
            msgbox('Database is empty.','Database result','help');
        end


% --- Executes during object creation, after setting all properties.
function ti_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ti (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function ti_Callback(hObject, eventdata, handles)
% hObject    handle to ti (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ti as text
%        str2double(get(hObject,'String')) returns contents of ti as a double


% --- Executes during object creation, after setting all properties.
function tc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function tc_Callback(hObject, eventdata, handles)
% hObject    handle to tc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tc as text
%        str2double(get(hObject,'String')) returns contents of tc as a double


% --- Executes during object creation, after setting all properties.
function C_CreateFcn(hObject, eventdata, handles)
% hObject    handle to C (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function C_Callback(hObject, eventdata, handles)
% hObject    handle to C (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of C as text
%        str2double(get(hObject,'String')) returns contents of C as a double


% --- Executes during object creation, after setting all properties.
function c2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to c2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function c2_Callback(hObject, eventdata, handles)
% hObject    handle to c2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of c2 as text
%        str2double(get(hObject,'String')) returns contents of c2 as a double


