function [newfiltro]=facegabor(L,mu,ni)
%
% function [newfiltro]=facegabor(L,mu,ni)
%
% L:  size of x-axis and y-axis  -L <= x <= +L and -L <= y <= +L
% mu: Gabor filter orientation angle. Possible values: 0,1,2,3,4,5,6,7
%     Angle is mu*pi/8
% ni: Gabor filter frequency. Possible values: 0,1,2,3,4
%
% Note that the 2D integral of the filter is equal to zero.


x=[-L:1:L];
y=[-L:1:L];
lx = length(x);
ly = length(y);

newfiltro = zeros(lx,ly);

kni   = 2^(-(ni+2)/2)*pi;
sigma = 2*pi;
fimu  = mu*pi/8;
kjx   = kni*cos(fimu);
kjy   = kni*sin(fimu);

for ii=1:lx
    for jj=1:ly
        newfiltro(ii,jj) = (kni^2)/(sigma^2)*...
            exp(-(kni^2*x(ii)^2+kni^2*y(jj)^2)/(2*sigma^2))*...
            (exp(i*(kjx*x(ii)+kjy*y(jj)))-exp(-sigma^2/2));
    end
end
%--------------------------------------------------------------------------
